<!DOCTYPE html>
<html> <head>
<title>User Blog</title>
</head>
<body>
<?php
function handle_post() {
  $dir="blog/";
  $filePrefix="comment";
  $upload_dir="uploads/";
  $target_file = $upload_dir.basename($_FILES["upload_file"]["name"]);
  $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);

  if(!file_exists($upload_dir)) {
    mkdir($upload_dir, 0711);
  }
  if (!file_exists($dir)) {
      mkdir($dir);
      chmod($dir, 0711);
  }
  //check error
  if($_FILES["upload_file"]["error"]<>0 ) {
    switch($_FILES["upload_file"]["error"] )
    {
      case 1:
        echo "The uploaded file exceeds the upload_max_filesize directive in php.ini.<br />";
        break;
      case 2:
        echo "The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form." . "<br />";
        break;
      case 3:
        echo "The uploaded file was only partially uploaded. " . "<br />";
        break;
      case 4:
        echo "No file was uploaded." . "<br />";
        break;
      case 6:
        echo "Missing a temporary folder." . "<br />";
        break;
      case 7:
        echo "Failed to write file to disk." . "<br />";
        break;
      case 8:
        echo "Failed to write file to disk." . "<br />";
        break;
    }
  }
  //Save comment
  $time=microtime();
  $timeArray = explode(" ", $time);
  $timeStamp = (float) $timeArray[1];
  if(isset($_POST['submit_comment_data'])) {
    $newEntry = date("H:i:s d/m/Y")." ".$_REQUEST["name"] . " " . $_REQUEST["comment"] . "<br/>";
    $file= $dir . $filePrefix . $timeStamp;
    if(file_put_contents($file, $newEntry) >0)
      echo "Comment was successfully written to " . htmlentities($file) . "<br/>";
    else
      echo "Comment could not be written to " . htmlentities($file) . "<br/>";
  }

  //check image uploaded file.
  $check = getimagesize($_FILES["upload_file"]["tmp_name"]);
  if($check !== false) {
    echo "File is an image - " . $check["mime"] . ".<br/>";
    $uploadOk = 1;
  } else {
    echo "File is not an image.<br/>";
    $uploadOk = 0;
  }
  //Check if file already exists.
  if (file_exists($target_file)) {
    echo "Sorry, file already exists.<br/>";
    $uploadOk = 0;
  }
// Check file size
  if ($_FILES["upload_file"]["size"] > 2000000) {
    echo "Sorry, your file is too large.<br/>";
    $uploadOk = 0;
  }
  // Allow certain file formats
  if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"&& $imageFileType != "gif" ) {
    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed. <br/>";
    $uploadOk = 0;
  }

  //Complete check
  if ($uploadOk == 1) {
    if (move_uploaded_file($_FILES["upload_file"]["tmp_name"],$file.'.'.$imageFileType)) {
      //chmod($upload_dir . $_FILES["upload_file"]["name"], 0644);
      chmod($file.$imageFileType, 0644);
      echo "File was saved <br/>";
    }
  } else {
    echo "Your file was not uploaded.<br/>";
  }
  echo "<hr>";

  //Display comment
  $files=scandir($dir);
  foreach($files as $f) {
    $path_parts = pathinfo($dir.$f);
    if ($path_parts['extension'] == 'jpg' || $path_parts['extension'] == 'png'||$path_parts['extension'] == 'jpeg'||$path_parts['extension'] == 'gif'){
        echo '<img src= "'.$dir.$f.'"height=200 width=300><br/>';
    } else {
      if (substr($f, 0, strlen($filePrefix)) == $filePrefix) echo file_get_contents($dir . $f);
    }
  }
}
handle_post();
echo "<hr>";
echo "<a href='example_9.html'>Main Page</a>";
?>
</body>
</html>
